#bin/bash
#
# Restore SELinux
#
# Author: Miguel Perdices
#
# Version: 0.9 (Apr 28)
#

sudo restorecon -R /data/envs
