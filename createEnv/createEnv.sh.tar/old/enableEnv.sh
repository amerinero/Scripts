# Author: Miguel Perdices
#
# Version: 0.9 (April 2018)
#

env=$1
conf=$2

echo "include $1/*.conf;" >> $2
