# Author: Miguel Perdices
#
# Version: 1.0 (Mayo 2018)
#

mkdir -p $1
